const modulos = [
  {
    titulo: "Módulo 1: Primeros Pasos",
    desc: "Conceptos básicos sobre IA Generativa, prompts y límites.",
    lecciones: [
      {
        titulo: "1.1 Qué es la IA Generativa",
        def: "Tecnología capaz de crear texto, imágenes o código a partir de patrones aprendidos.",
        tip: "Escribe instrucciones claras indicando contexto y formato.",
        practica: "Verifica siempre los datos entregados antes de usarlos."
      }
    ],
    quiz: {
      pregunta: "¿La IA Generativa siempre entrega información 100% verídica?",
      opciones: [
        { texto: "A) Verdadero, nunca comete errores.", ok: false },
        { texto: "B) Falso, puede generar datos imprecisos que deben verificarse.", ok: true }
      ],
      retro: "Los modelos predicen texto probable, no comprueban hechos reales."
    }
  },
  {
    titulo: "Módulo 2: Ética y Privacidad",
    desc: "Protección de datos personales, sesgos y prevención de plagio.",
    lecciones: [
      {
        titulo: "2.1 Protección de Datos",
        def: "Resguardo de información sensible antes de interactuar con chats públicos.",
        tip: "Sustituye nombres y correos reales por ejemplos ficticios.",
        practica: "No subas contraseñas ni documentos confidenciales a herramientas abiertas."
      }
    ],
    quiz: {
      pregunta: "¿Es seguro pegar teléfonos reales de clientes en un chat gratuito de IA?",
      opciones: [
        { texto: "A) No, expone datos personales y vulnera la privacidad.", ok: true },
        { texto: "B) Sí, si se borra la conversación al terminar.", ok: false }
      ],
      retro: "Toda información personal debe anonimizarse previamente."
    }
  },
  {
    titulo: "Módulo 3: Reglas Claras",
    desc: "Citación de herramientas, honestidad académica y criterio humano.",
    lecciones: [
      {
        titulo: "3.1 Transparencia y Autoría",
        def: "Declarar el uso de IA como herramienta de apoyo manteniendo el criterio propio.",
        tip: "Úsala para estructurar ideas, no para sustituir tu análisis.",
        practica: "Cita la herramienta utilizada según las reglas de tu institución."
      }
    ],
    quiz: {
      pregunta: "¿Cuál es la conducta ética al entregar un trabajo apoyado con IA?",
      opciones: [
        { texto: "A) Entregar el texto generado sin revisarlo.", ok: false },
        { texto: "B) Revisar, editar con criterio propio y declarar su uso.", ok: true }
      ],
      retro: "La responsabilidad final del contenido recae en el autor humano."
    }
  }
];

let modAdmin = 0;

function cargarCatalogo() {
  document.getElementById("lista-modulos").innerHTML = modulos.map((m, i) => `
    <div class="tarjeta">
      <h3>${m.titulo}</h3>
      <p>${m.desc}</p>
      <button class="btn-primario" onclick="abrirModulo(${i})">Ver Módulo</button>
    </div>
  `).join("");
}

function abrirModulo(i) {
  const m = modulos[i];
  document.getElementById("catalogo-modulos").classList.add("oculto");
  document.getElementById("detalle-modulo").classList.remove("oculto");
  document.getElementById("titulo-modulo").textContent = m.titulo;

  document.getElementById("contenido-leccion").innerHTML = m.lecciones.map(l => `
    <div class="tarjeta">
      <h3>${l.titulo}</h3>
      <p><strong>Definición:</strong> ${l.def}</p>
      <div class="bloque-dos">
        <div class="caja-info"><strong>Tip:</strong> ${l.tip}</div>
        <div class="caja-info"><strong>Buena práctica:</strong> ${l.practica}</div>
      </div>
    </div>
  `).join("");

  document.getElementById("pregunta-texto").textContent = m.quiz.pregunta;
  document.getElementById("pregunta-feedback").classList.add("oculto");
  document.getElementById("pregunta-opciones").innerHTML = m.quiz.opciones.map(op => `
    <button class="btn-opcion" onclick="responder(${op.ok}, '${m.quiz.retro}')">${op.texto}</button>
  `).join("");
}

function responder(esOk, retro) {
  const fb = document.getElementById("pregunta-feedback");
  fb.className = esOk ? "feedback ok" : "feedback mal";
  fb.textContent = (esOk ? "Correcto: " : "Incorrecto: ") + retro;
}

function volverCatalogo() {
  document.getElementById("detalle-modulo").classList.add("oculto");
  document.getElementById("catalogo-modulos").classList.remove("oculto");
}

function abrirLogin() { document.getElementById("modal-login").classList.remove("oculto"); }
function cerrarLogin() { document.getElementById("modal-login").classList.add("oculto"); }

function validarLogin() {
  if (document.getElementById("user").value === "admin" && document.getElementById("pass").value === "1234") {
    cerrarLogin();
    document.getElementById("vista-estudiante").classList.add("oculto");
    document.getElementById("vista-admin").classList.remove("oculto");
    seleccionarModuloAdmin(0);
  } else {
    document.getElementById("error-login").classList.remove("oculto");
  }
}

function mostrarEstudiante() {
  document.getElementById("vista-admin").classList.add("oculto");
  document.getElementById("vista-estudiante").classList.remove("oculto");
  volverCatalogo();
  cargarCatalogo();
}

function seleccionarModuloAdmin(i) {
  modAdmin = i;
  document.querySelectorAll(".sidebar li").forEach((li, idx) => li.classList.toggle("active", idx === i));
  document.getElementById("titulo-admin").textContent = "Gestión: " + modulos[i].titulo;
  renderTablaAdmin();
}

function renderTablaAdmin() {
  document.getElementById("tabla-admin").innerHTML = modulos[modAdmin].lecciones.map((l, idx) => `
    <tr>
      <td>${l.titulo}</td>
      <td>${l.tip}</td>
      <td><button class="btn-borrar" onclick="borrarLeccion(${idx})">Eliminar</button></td>
    </tr>
  `).join("");
}

function agregarLeccion(e) {
  e.preventDefault();
  modulos[modAdmin].lecciones.push({
    titulo: document.getElementById("f-titulo").value,
    def: document.getElementById("f-definicion").value,
    tip: document.getElementById("f-tip").value,
    practica: document.getElementById("f-practica").value
  });
  e.target.reset();
  renderTablaAdmin();
}

function borrarLeccion(idx) {
  modulos[modAdmin].lecciones.splice(idx, 1);
  renderTablaAdmin();
}

cargarCatalogo();